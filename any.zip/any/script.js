const stateData = {
    'Maharashtra': 4637018,
    'Uttar-pradesh': 2682240,
    'Andaman and Nicobar Islands': 13102,
    'Andhra Pradesh': 916471,
    'Arunachal Pradesh': 14107,
    'Assam': 533429,
    'Bihar': 1139751,
    'Chandigarh': 43105,
    'Chhattisgarh': 398867,
    'DNHDD': 20172,
    'Delhi': 685331,
    'Goa': 56540,
    'Gujarat': 1989161,
    'Haryana': 916074,
    'Himachal Pradesh': 170114,
    'Jammu and Kashmir': 434989,
    'Jharkhand': 478897,
    'Karnataka': 1596764,
    'Kerala': 662569,
    'Ladakh': 11183,
    'Lakshadweep': 969,
    'Madhya Pradesh': 1348599,
    'Manipur': 73614,
    'Meghalaya': 23985,
    'Mizoram': 24476,
    'Nagaland': 25758,
    'Odisha': 868703,
    'Puducherry': 40738,
    'Punjab': 1075328,
    'Rajasthan': 2017131,
    'Sikkim': 11355,
    'Tamil Nadu': 2775605,
    'Telangana': 986625,
    'Tripura': 62101,
    'Uttarakhand': 275791,
    'West Bengal': 1168077

    // Add data for all other states
};

// Function to get color based on MSME count
function getColor(msmeCount) {
    if (msmeCount > 4000000) return '#006bbb'; // Darkest
    if (msmeCount > 3000000) return '#1e9ee0';
    if (msmeCount > 1500000) return '#40bff7';
    if (msmeCount > 100000) return '#68d3fa';
    if (msmeCount > 979) return '#95e3fc';
    return '#cff3ff'; // Lightest
}

// Apply colors to states
for (let state in stateData) {
    const pathElement = document.getElementById(state);
    if (pathElement) {
        pathElement.style.fill = getColor(stateData[state]);
    }
}